from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
# Create your views here.

def home(request):
    # template = loader.get_template("C:\\Users\\super\\Envs\\tut_django\\proj1\\new_project\\calc\\templates\\first.html")
    return render(request,'home.html',{'name':'Luffy'})

def add(request):
    n1 = request.POST['num1']
    n2 = request.POST['num2']
    res = int(n1) + int(n2)
    return render(request, 'results.html',{'result':res})

def intro(request):
    return render(request, 'my_first.html',{'name':'Brook'})